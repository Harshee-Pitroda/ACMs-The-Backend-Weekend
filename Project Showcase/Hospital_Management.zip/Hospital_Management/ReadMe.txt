--> To run this project:
 
1. IDE recommmended - VSCode, Sublime Text, PyCharm
2. Before Launching the web application run the following lines of code in your local system terminal to install the required packages:
	a. pip install flask
	b. pip install WTForms
	c. pip install Flask-Login
	d. pip install flask-migrate
	e. pip install python-secrets
3. After successfully installing all the packages above open the main folder Hospital_Management
4. Open an integrated terminal or CMD and redirect to he current directory
5. run the code - 'python run.py'
6. The web application will be hosted on the local port: 8000
7. Open a new tab on your web browser and type in - 'localhost:5000'

Password to the account - 123456
 